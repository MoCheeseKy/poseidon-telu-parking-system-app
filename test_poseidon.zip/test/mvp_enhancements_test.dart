import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:poseidon/core/theme/app_theme.dart';
import 'package:poseidon/data/mock/mock_building_data.dart';
import 'package:poseidon/data/mock/mock_parking_data.dart';
import 'package:poseidon/data/models/building.dart';
import 'package:poseidon/data/models/parking_location.dart';
import 'package:poseidon/services/location_service.dart';
import 'package:poseidon/services/recommendation_service.dart';
import 'package:poseidon/ui/core/widgets/parking_tooltip_marker.dart';
import 'package:poseidon/ui/features/home/views/home_map_screen.dart';
import 'package:poseidon/ui/features/search/views/search_destination_sheet.dart';

class FakeGeolocatorAdapter implements GeolocatorAdapter {
  bool serviceEnabled;
  LocationPermission initialPermission;
  LocationPermission requestedPermission;
  LatLng coordinatesToReturn;
  Object? errorToThrow;

  int serviceCheckCount = 0;
  int checkPermissionCount = 0;
  int requestPermissionCount = 0;
  int getCurrentCoordinatesCount = 0;

  FakeGeolocatorAdapter({
    this.serviceEnabled = true,
    this.initialPermission = LocationPermission.whileInUse,
    this.requestedPermission = LocationPermission.whileInUse,
    this.coordinatesToReturn = const LatLng(-6.973200, 107.630500),
    this.errorToThrow,
  });

  @override
  Future<bool> isLocationServiceEnabled() async {
    serviceCheckCount++;
    return serviceEnabled;
  }

  @override
  Future<LocationPermission> checkPermission() async {
    checkPermissionCount++;
    return initialPermission;
  }

  @override
  Future<LocationPermission> requestPermission() async {
    requestPermissionCount++;
    return requestedPermission;
  }

  @override
  Future<LatLng> getCurrentCoordinates({
    Duration timeLimit = const Duration(seconds: 10),
  }) async {
    getCurrentCoordinatesCount++;
    if (errorToThrow != null) {
      throw errorToThrow!;
    }
    return coordinatesToReturn;
  }

  @override
  Future<bool> openAppSettings() async => true;

  @override
  Future<bool> openLocationSettings() async => true;
}

void main() {
  group('Feature B: Building Master Data Tests', () {
    test('provides recognizable campus buildings with separated center and entrance coordinates', () {
      final buildings = MockBuildingData.getAllBuildings();
      expect(buildings.length, greaterThanOrEqualTo(5));

      final codes = buildings.map((b) => b.code).toSet();
      expect(codes, containsAll(['TULT', 'GKU', 'FIT', 'FEB', 'REKTORAT']));

      for (final b in buildings) {
        expect(b.hasValidCoordinates, isTrue);
        expect(
          b.latitude != b.entranceLatitude ||
              b.longitude != b.entranceLongitude,
          isTrue,
          reason: '${b.name} must separate center and entrance coordinates',
        );
      }
    });

    test('searches buildings by name or code and finds by ID', () {
      expect(MockBuildingData.searchBuildings('').length, equals(MockBuildingData.getAllBuildings().length));
      expect(MockBuildingData.searchBuildings('tult').first.id, equals('tult'));
      expect(MockBuildingData.searchBuildings('Rektorat').first.id, equals('rektorat'));
      expect(MockBuildingData.searchBuildings('gedung tidak ada'), isEmpty);

      expect(MockBuildingData.findById('FEB')?.code, equals('FEB'));
      expect(MockBuildingData.findById('unknown_id'), isNull);
    });
  });

  group('Feature C: RecommendationService Tests', () {
    const service = RecommendationService();

    test('recommends closest compatible parking and excludes full/offline/zero-slot locations', () {
      // FKS Motor parking is right next to FKS building but has 0 slots & status full -> must be excluded!
      final fksBuilding = MockBuildingData.findById('fks')!;
      final fksResult = service.recommend(
        destination: fksBuilding,
        vehicleType: VehicleType.motor,
        parkingLocations: MockParkingData.allLocations,
      );

      expect(fksResult.hasRecommendation, isTrue);
      expect(fksResult.bestRecommendation!.parkingLocation.id, isNot('fks_motor'));
      expect(fksResult.bestRecommendation!.parkingLocation.id, equals('fit_motor'));
      expect(
        fksResult.alternatives.any((alt) => alt.parkingLocation.id == 'fks_motor'),
        isFalse,
      );

      // Damar Mobil parking has 0 slots & status full -> must recommend Penambulai Mobil instead!
      final damarBuilding = MockBuildingData.findById('damar')!;
      final damarMobilResult = service.recommend(
        destination: damarBuilding,
        vehicleType: VehicleType.mobil,
        parkingLocations: MockParkingData.allLocations,
      );

      expect(damarMobilResult.hasRecommendation, isTrue);
      expect(
        damarMobilResult.bestRecommendation!.parkingLocation.id,
        equals('penambulai_mobil'),
      );
    });

    test('handles offline, invalid coordinates, and unavailable parking edge cases safely', () {
      final tult = MockBuildingData.tultBuilding;
      const customLocations = [
        ParkingLocation(
          id: 'offline_lot',
          name: 'Parkir Offline',
          vehicleType: VehicleType.motor,
          availableSlots: 25,
          occupiedSlots: 10,
          totalSlots: 35,
          status: ParkingStatus.offline,
          latitude: -6.969510,
          longitude: 107.628920,
        ),
        ParkingLocation(
          id: 'invalid_coord_lot',
          name: 'Parkir Koordinat Rusak',
          vehicleType: VehicleType.motor,
          availableSlots: 40,
          occupiedSlots: 10,
          totalSlots: 50,
          status: ParkingStatus.available,
          latitude: double.nan,
          longitude: 107.628920,
        ),
      ];

      final unavailableResult = service.recommend(
        destination: tult,
        vehicleType: VehicleType.motor,
        parkingLocations: customLocations,
      );
      expect(unavailableResult.hasRecommendation, isFalse);
      expect(
        unavailableResult.emptyReason,
        equals(RecommendationEmptyReason.allCompatibleParkingUnavailable),
      );

      final noVehicleResult = service.recommend(
        destination: tult,
        vehicleType: VehicleType.mobil,
        parkingLocations: customLocations,
      );
      expect(noVehicleResult.hasRecommendation, isFalse);
      expect(
        noVehicleResult.emptyReason,
        equals(RecommendationEmptyReason.noCompatibleVehicleParking),
      );

      const invalidBuilding = Building(
        id: 'bad',
        name: 'Invalid',
        code: 'BAD',
        latitude: 0.0,
        longitude: 0.0,
        entranceLatitude: 0.0,
        entranceLongitude: 0.0,
      );
      final badDestResult = service.recommend(
        destination: invalidBuilding,
        vehicleType: VehicleType.motor,
        parkingLocations: MockParkingData.allLocations,
      );
      expect(badDestResult.hasRecommendation, isFalse);
      expect(
        badDestResult.emptyReason,
        equals(RecommendationEmptyReason.invalidDestinationCoordinates),
      );
    });
  });

  group('Feature D: Functional SearchDestinationSheet Widget Tests', () {
    testWidgets(
      'filters buildings as user types, handles no-match state, recalculates on destination & vehicle change, and selects alternative',
      (WidgetTester tester) async {
        ParkingLocation? selectedParking;
        await tester.binding.setSurfaceSize(const Size(400, 850));
        await tester.pumpWidget(
          MaterialApp(
            theme: AppTheme.lightTheme,
            home: Scaffold(
              body: SearchDestinationSheet(
                onParkingSelected: (loc) => selectedParking = loc,
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();

        // Type non-matching building -> shows friendly empty building search state
        await tester.enterText(
          find.byKey(const Key('destination_search_text_field')),
          'Gedung Mars 99',
        );
        await tester.pumpAndSettle();
        expect(find.byKey(const Key('no_matching_building_state')), findsOneWidget);

        // Type "Rektorat" -> filters list to Gedung Rektorat
        await tester.enterText(
          find.byKey(const Key('destination_search_text_field')),
          'Rektorat',
        );
        await tester.pumpAndSettle();
        expect(find.byKey(const ValueKey('building_result_rektorat')), findsOneWidget);

        // Select Gedung Rektorat -> recalculates recommendation for Motor (Parkiran MSU Motor)
        await tester.tap(find.byKey(const ValueKey('building_result_rektorat')));
        await tester.pumpAndSettle();
        expect(find.text('Rekomendasi'), findsOneWidget);
        expect(find.textContaining('Tujuan REKTORAT'), findsNothing);
        expect(find.text('Parkiran MSU (Motor)'), findsOneWidget);

        // Switch vehicle to Mobil -> recalculates recommendation to Parkiran Penambulai (Mobil)
        await tester.tap(find.text('Mobil'));
        await tester.pumpAndSettle();
        expect(find.text('Parkiran Penambulai (Mobil)'), findsOneWidget);
        expect(find.text('Parkir Mobil'), findsNothing);

        // Select an alternative parking location -> triggers onParkingSelected
        final altFinder = find.byKey(
          const ValueKey('search_alternative_gedung_ef_mobil'),
        );
        await tester.ensureVisible(altFinder);
        await tester.pumpAndSettle();
        await tester.tap(altFinder);
        await tester.pumpAndSettle();
        expect(selectedParking?.id, equals('gedung_ef_mobil'));
      },
    );

    testWidgets('displays proper empty state when no parking slots are available', (
      WidgetTester tester,
    ) async {
      await tester.binding.setSurfaceSize(const Size(400, 850));
      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.lightTheme,
          home: const Scaffold(
            body: SearchDestinationSheet(
              parkingLocations: [MockParkingData.fksMotorParking],
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.byKey(const Key('empty_recommendation_state')), findsOneWidget);
      expect(find.text('Parkiran Motor Sedang Penuh'), findsOneWidget);
    });
  });

  group('Feature A & E: GPS Current Location & Demo Route Visualization Tests', () {
    testWidgets(
      'does NOT request GPS on launch; handles denied/disabled states gracefully; shows user marker and clearable demo route when parking is selected',
      (WidgetTester tester) async {
        final fakeAdapter = FakeGeolocatorAdapter(
          serviceEnabled: false,
          initialPermission: LocationPermission.denied,
          requestedPermission: LocationPermission.denied,
        );
        final locationService = LocationService(adapter: fakeAdapter);

        await tester.binding.setSurfaceSize(const Size(400, 850));
        await tester.pumpWidget(
          MaterialApp(
            theme: AppTheme.lightTheme,
            home: HomeMapScreen(locationService: locationService),
          ),
        );
        await tester.pumpAndSettle();

        // 1. Verify NO GPS check or permission prompt occurred on app launch!
        expect(fakeAdapter.serviceCheckCount, equals(0));
        expect(fakeAdapter.checkPermissionCount, equals(0));
        expect(fakeAdapter.requestPermissionCount, equals(0));
        expect(find.byKey(const Key('user_current_location_marker')), findsNothing);

        // 2. Tap GPS button while GPS is disabled -> shows friendly message, does not crash
        await tester.tap(find.byKey(const Key('gps_current_location_button')));
        await tester.pumpAndSettle();
        expect(fakeAdapter.serviceCheckCount, equals(1));
        expect(find.textContaining('Layanan lokasi (GPS) belum aktif'), findsOneWidget);

        // 3. Enable GPS service, but deny permission -> shows friendly permission message
        fakeAdapter.serviceEnabled = true;
        await tester.tap(find.byKey(const Key('gps_current_location_button')));
        await tester.pumpAndSettle();
        expect(fakeAdapter.requestPermissionCount, equals(1));
        expect(find.textContaining('Izin lokasi ditolak'), findsOneWidget);

        // 4. Grant permission & return campus GPS coordinates -> shows user marker on map
        fakeAdapter.requestedPermission = LocationPermission.whileInUse;
        fakeAdapter.coordinatesToReturn = const LatLng(-6.972800, 107.630100);
        await tester.tap(find.byKey(const Key('gps_current_location_button')));
        await tester.pumpAndSettle();

        expect(find.byKey(const Key('user_current_location_marker')), findsOneWidget);
        // No parking selected yet -> demo route polyline must NOT be shown
        expect(find.byKey(const Key('demo_route_polyline_layer')), findsNothing);

        // Reset camera to campus overview via distinct campus reset button -> user GPS marker stays visible!
        await tester.tap(find.byKey(const Key('reset_map_position_button')));
        await tester.pumpAndSettle();
        expect(find.byKey(const Key('user_current_location_marker')), findsOneWidget);

        // 5. Select a parking marker -> demo straight-line route & disclaimer pill appear while parking markers stay visible
        await tester.tap(
          find.byKey(const ValueKey('parking_marker_tult_motor')),
        );
        await tester.pumpAndSettle();

        expect(find.byType(PolylineLayer), findsOneWidget);
        expect(find.byKey(const Key('demo_route_info_pill')), findsOneWidget);
        expect(
          find.textContaining('estimasi, bukan rute jalan'),
          findsOneWidget,
        );
        expect(
          find.byType(ParkingTooltipMarker),
          findsNWidgets(MockParkingData.motorLocations.length),
        );

        // 6. Clear demo route via pill close button -> route disappears while markers & selection remain
        await tester.tap(find.byKey(const Key('clear_demo_route_button')));
        await tester.pumpAndSettle();
        expect(find.byType(PolylineLayer), findsNothing);
        expect(find.byKey(const Key('demo_route_info_pill')), findsNothing);
        expect(
          find.byKey(const Key('selected_parking_compact_sheet')),
          findsOneWidget,
        );
      },
    );

    test('LocationService handles permanently denied and timeout errors gracefully', () async {
      final deniedForeverAdapter = FakeGeolocatorAdapter(
        serviceEnabled: true,
        initialPermission: LocationPermission.deniedForever,
      );
      final deniedForeverResult = await LocationService(
        adapter: deniedForeverAdapter,
      ).getCurrentLocation();
      expect(deniedForeverResult.isSuccess, isFalse);
      expect(
        deniedForeverResult.status,
        equals(LocationResultStatus.permissionPermanentlyDenied),
      );

      final timeoutAdapter = FakeGeolocatorAdapter(
        serviceEnabled: true,
        initialPermission: LocationPermission.always,
        errorToThrow: TimeoutException('GPS timeout'),
      );
      final timeoutResult = await LocationService(
        adapter: timeoutAdapter,
      ).getCurrentLocation();
      expect(timeoutResult.isSuccess, isFalse);
      expect(timeoutResult.status, equals(LocationResultStatus.error));
    });
  });
}
