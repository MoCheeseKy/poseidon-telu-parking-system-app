import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:poseidon/core/constants/app_colors.dart';
import 'package:poseidon/core/theme/app_theme.dart';
import 'package:poseidon/data/mock/mock_notification_data.dart';
import 'package:poseidon/data/mock/mock_user_profile_data.dart';
import 'package:poseidon/data/models/report_item.dart';
import 'package:poseidon/services/report_media_service.dart';
import 'package:poseidon/ui/features/home/views/home_map_screen.dart';
import 'package:poseidon/ui/features/notifications/views/notification_screen.dart';
import 'package:poseidon/ui/features/profile/views/about_us_screen.dart';
import 'package:poseidon/ui/features/profile/views/help_center_screen.dart';
import 'package:poseidon/ui/features/profile/views/profile_screen.dart';
import 'package:poseidon/ui/features/report/views/camera_capture_screen.dart';
import 'package:poseidon/ui/features/report/views/create_report_screen.dart';

class _FakeReportMediaService extends ReportMediaService {
  final Uint8List samplePngBytes;

  const _FakeReportMediaService(this.samplePngBytes);

  @override
  Future<CapturedReportPhoto?> captureFromCamera(BuildContext context) async {
    return CapturedReportPhoto(
      bytes: samplePngBytes,
      fileName: 'kamera_parkir_tult.jpg',
      source: ReportPhotoSource.camera,
    );
  }

  @override
  Future<CapturedReportPhoto?> pickFromSystem() async {
    return CapturedReportPhoto(
      bytes: samplePngBytes,
      fileName: 'galeri_bukti_akses.png',
      source: ReportPhotoSource.systemGallery,
    );
  }
}

final Uint8List _oneByOnePng = base64Decode(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
);

Widget _wrapWithTheme(Widget home) {
  return MaterialApp(
    theme: AppTheme.lightTheme,
    home: home,
  );
}

void main() {
  setUp(() {
    MockNotificationData.sharedStore.resetToDefault();
    MockUserProfileData.sharedStore.resetToDefault();
  });

  test('Global theme uses Plus Jakarta Sans and #FDF6F6 page background', () {
    final theme = AppTheme.lightTheme;
    expect(AppTheme.fontFamily, 'Plus Jakarta Sans');
    expect(AppColors.pageBackground, const Color(0xFFFDF6F6));
    expect(theme.scaffoldBackgroundColor, const Color(0xFFFDF6F6));
  });

  testWidgets(
    'NotificationScreen renders unread/read sections, filters, and marks all as read',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      final store = NotificationStore();
      await tester.pumpWidget(_wrapWithTheme(NotificationScreen(store: store)));

      expect(find.text('Notifikasi'), findsOneWidget);
      expect(find.text('Semua'), findsOneWidget);
      expect(
        find.textContaining('Belum Dibaca', findRichText: true),
        findsOneWidget,
      );
      expect(find.text('Tandai Dibaca'), findsOneWidget);
      expect(find.text('HARI INI'), findsOneWidget);
      expect(find.text('2 Notifikasi Baru'), findsOneWidget);
      expect(find.text('KEMARIN'), findsOneWidget);
      expect(find.text('Laporan Sedang Ditinjau Petugas'), findsOneWidget);
      expect(find.text('Sensor Offline — Parkir Nanas'), findsOneWidget);

      // Filter by Unread
      await tester.tap(find.textContaining('Belum Dibaca', findRichText: true));
      await tester.pumpAndSettle();

      expect(find.text('Laporan Sedang Ditinjau Petugas'), findsOneWidget);
      expect(find.text('Laporan Selesai Ditangani'), findsNothing);

      // Mark all as read
      await tester.tap(find.text('Tandai Dibaca'));
      await tester.pumpAndSettle();

      expect(store.unreadCount, 0);
      expect(find.text('Tidak ada notifikasi yang belum dibaca.'), findsOneWidget);
    },
  );

  testWidgets(
    'HelpCenterScreen starts with all FAQs collapsed, supports search, and wires +6281210714320',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      Uri? launchedUri;
      await tester.pumpWidget(
        _wrapWithTheme(
          HelpCenterScreen(
            urlLauncherOverride: (uri) async {
              launchedUri = uri;
              return true;
            },
          ),
        ),
      );

      expect(find.text('Pusat Bantuan'), findsNWidgets(2));
      expect(find.text('5 Topik'), findsOneWidget);
      // Default state: NO FAQ card is expanded
      expect(find.text('Epistemic Sensor Logic'), findsNothing);

      // Tap first FAQ to expand
      await tester.tap(
        find.text(
          "Mengapa jumlah slot parkir tidak tersedia atau bertuliskan 'Kapasitas belum diketahui'?",
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('Epistemic Sensor Logic'), findsOneWidget);

      // Search FAQ
      await tester.enterText(find.byType(TextField), 'Sensor Offline');
      await tester.pumpAndSettle();
      expect(find.text('1 Topik'), findsOneWidget);

      // Clear search
      await tester.tap(find.byTooltip('Bersihkan pencarian'));
      await tester.pumpAndSettle();
      expect(find.text('5 Topik'), findsOneWidget);

      // Scroll to Jam Operasional & tap Hubungi Kami
      await tester.scrollUntilVisible(
        find.text('Hubungi Kami'),
        220.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Hubungi Kami'));
      await tester.pumpAndSettle();

      expect(find.text('+6281210714320'), findsOneWidget);
      expect(find.text('Telepon Langsung'), findsOneWidget);

      await tester.tap(find.text('Chat melalui WhatsApp'));
      await tester.pumpAndSettle();

      expect(launchedUri, isNotNull);
      expect(launchedUri.toString(), contains('6281210714320'));
    },
  );

  testWidgets(
    'AboutUsScreen renders Poseidon brand hero, version 1.2.0, and single-entry changelog',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      await tester.pumpWidget(_wrapWithTheme(const AboutUsScreen()));

      expect(find.text('Poseidon'), findsOneWidget);
      expect(
        find.text('Smart Parking System Telkom University Bandung'),
        findsOneWidget,
      );
      expect(find.text('Versi 1.2.0'), findsOneWidget);
      expect(find.text('INFORMASI & LEGALITAS'), findsOneWidget);

      await tester.scrollUntilVisible(
        find.text('Catatan Rilis Pembaruan (Changelog)'),
        180.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Catatan Rilis Pembaruan (Changelog)'));
      await tester.pumpAndSettle();

      expect(find.text('Rilis Antarmuka Aplikasi'), findsOneWidget);
      expect(find.text('Versi 1.1.0'), findsNothing);
      expect(find.text('Versi 1.0.0'), findsNothing);

      await tester.ensureVisible(find.text('Tutup'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Tutup'));
      await tester.pumpAndSettle();

      // Open Tentang Pengembang Aplikasi & verify all 4 team members
      await tester.scrollUntilVisible(
        find.text('Tentang Pengembang Aplikasi'),
        120.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Tentang Pengembang Aplikasi'));
      await tester.pumpAndSettle();

      expect(find.text('Rifky Muhammad Prayudhi'), findsOneWidget);
      expect(find.text('NIM 103022400003'), findsOneWidget);
      expect(find.text('Muhamad Naufal Nabillansyah'), findsOneWidget);
      expect(find.text('NIM 103022400073'), findsOneWidget);
      expect(find.text('Joanne Agnesia Nempung'), findsOneWidget);
      expect(find.text('NIM 103022400114'), findsOneWidget);
      expect(find.text('Aruna Jannu Rezasyah'), findsOneWidget);
      expect(find.text('NIM 103022430015'), findsOneWidget);

      await tester.ensureVisible(find.text('Tutup'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Tutup'));
      await tester.pumpAndSettle();
    },
  );

  testWidgets(
    'ProfileScreen supports logout and navigates to LoginScreen to log in again',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      final profileStore = UserProfileStore();
      await tester.pumpWidget(
        _wrapWithTheme(ProfileScreen(profileStore: profileStore)),
      );

      // Initially logged in
      expect(profileStore.isLoggedIn, isTrue);
      expect(find.byKey(const Key('logged_in_profile_card')), findsOneWidget);
      expect(find.byKey(const Key('profile_logout_button')), findsOneWidget);

      // Scroll and tap Logout button
      await tester.scrollUntilVisible(
        find.byKey(const Key('profile_logout_button')),
        250.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('profile_logout_button')));
      await tester.pumpAndSettle();

      // Dialog appears
      expect(
        find.text(
          'Apakah Anda yakin ingin keluar dari akun SSO Telkom University?',
        ),
        findsOneWidget,
      );
      await tester.tap(find.byKey(const Key('confirm_logout_button')));
      await tester.pumpAndSettle();

      // Now logged out
      expect(profileStore.isLoggedIn, isFalse);
      expect(find.byKey(const Key('guest_profile_card')), findsOneWidget);
      expect(find.text('Belum Masuk Akun'), findsOneWidget);

      // Tap Login button -> opens LoginScreen
      await tester.tap(find.byKey(const Key('profile_login_button')));
      await tester.pumpAndSettle();

      expect(find.text('Masuk ke Poseidon'), findsOneWidget);
      expect(find.byKey(const Key('login_email_input')), findsOneWidget);
      expect(find.byKey(const Key('login_password_input')), findsOneWidget);

      // Fill password & tap Masuk
      await tester.enterText(
        find.byKey(const Key('login_password_input')),
        'SecretPass123!',
      );
      await tester.tap(find.byKey(const Key('submit_login_button')));
      await tester.pumpAndSettle();

      // Back to ProfileScreen, logged in again
      expect(profileStore.isLoggedIn, isTrue);
      expect(find.byKey(const Key('logged_in_profile_card')), findsOneWidget);
      expect(find.text('Rifky Muhammad Prayudhi'), findsOneWidget);
    },
  );

  testWidgets(
    'ProfileScreen renders minimal profile card without clutter and navigates to sub-pages',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      final profileStore = UserProfileStore();
      await tester.pumpWidget(
        _wrapWithTheme(ProfileScreen(profileStore: profileStore)),
      );

      // Removed clutter checks
      expect(find.text('Akun Saya'), findsNothing);
      expect(find.text('Status SSO'), findsNothing);
      expect(find.text('Keluar dari Akun SSO'), findsNothing);

      // Minimal profile card: avatar, name, campus email
      expect(find.text('Rifky Muhammad Prayudhi'), findsOneWidget);
      expect(
        find.text('rifkymuhammad@student.telkomuniversity.ac.id'),
        findsOneWidget,
      );

      // Clean menu rows
      expect(find.text('Edit Profil'), findsOneWidget);
      expect(find.text('Kendaraan Terdaftar'), findsOneWidget);
      expect(find.text('Lokasi Parkir Favorit'), findsOneWidget);
      expect(find.text('Pengaturan Notifikasi'), findsOneWidget);

      // Open Kendaraan Terdaftar
      await tester.tap(find.text('Kendaraan Terdaftar'));
      await tester.pumpAndSettle();
      expect(find.text('Honda Vario 160'), findsOneWidget);
      expect(find.text('2 Unit'), findsOneWidget);

      await tester.tap(find.byIcon(Icons.arrow_back));
      await tester.pumpAndSettle();

      // Open Pengaturan Notifikasi & verify inbox button is removed
      await tester.tap(find.text('Pengaturan Notifikasi'));
      await tester.pumpAndSettle();
      expect(find.text('Pembaruan Laporan Parkir'), findsOneWidget);
      expect(find.text('Buka Kotak Masuk Notifikasi'), findsNothing);
    },
  );

  testWidgets(
    'HomeMapScreen Akun tab renders clean ProfileScreen',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      await tester.pumpWidget(_wrapWithTheme(const HomeMapScreen()));

      await tester.tap(find.text('Akun'));
      await tester.pumpAndSettle();

      expect(find.text('Akun Saya'), findsNothing);
      expect(find.text('Rifky Muhammad Prayudhi'), findsOneWidget);
      expect(find.text('Pusat Bantuan'), findsOneWidget);
      expect(find.text('Tentang Kami'), findsOneWidget);
    },
  );

  testWidgets(
    'CreateReportScreen supports attaching photo via Camera API and System Picker',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      ReportItem? submittedReport;
      final fakeMedia = _FakeReportMediaService(_oneByOnePng);

      await tester.pumpWidget(
        _wrapWithTheme(
          CreateReportScreen(
            mediaService: fakeMedia,
            onReportCreated: (item) {
              submittedReport = item;
            },
          ),
        ),
      );

      // Scroll down to Camera API & System Picker buttons
      await tester.scrollUntilVisible(
        find.text('Buka Kamera'),
        240.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();

      // Capture via Camera API button
      await tester.tap(find.text('Buka Kamera'));
      await tester.pumpAndSettle();

      expect(
        find.text('Foto terlampir: kamera_parkir_tult.jpg'),
        findsOneWidget,
      );

      // Switch to System Picker button
      await tester.scrollUntilVisible(
        find.text('Pilih dari Sistem'),
        150.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Pilih dari Sistem'));
      await tester.pumpAndSettle();

      expect(
        find.text('Foto terlampir: galeri_bukti_akses.png'),
        findsOneWidget,
      );

      // Dismiss floating feedback SnackBar before tapping bottom action
      await tester.pump(const Duration(seconds: 3));
      await tester.pumpAndSettle();

      // Open Review Sheet and submit
      await tester.scrollUntilVisible(
        find.text('Tinjau Laporan'),
        180.0,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('Tinjau Laporan'));
      await tester.pumpAndSettle();

      expect(find.text('1 Lampiran (PNG)'), findsOneWidget);
      expect(find.text('1 foto terverifikasi siap diunggah'), findsOneWidget);

      await tester.ensureVisible(find.text('Kirim Laporan'));
      await tester.tap(find.text('Kirim Laporan'));
      await tester.pumpAndSettle();

      expect(submittedReport, isNotNull);
      expect(submittedReport!.attachmentBytes, isNotNull);
      expect(submittedReport!.attachmentFileName, 'galeri_bukti_akses.png');
    },
  );

  testWidgets(
    'CameraCaptureScreen renders viewfinder, controls, and captures evidence photo via shutter button',
    (WidgetTester tester) async {
      await tester.binding.setSurfaceSize(const Size(412, 915));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      CameraCaptureResult? capturedResult;

      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.lightTheme,
          home: Builder(
            builder: (context) => Scaffold(
              body: ElevatedButton(
                onPressed: () async {
                  final result = await Navigator.push<CameraCaptureResult>(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const CameraCaptureScreen(cameras: []),
                    ),
                  );
                  capturedResult = result;
                },
                child: const Text('Buka Kamera'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Buka Kamera'));
      await tester.pumpAndSettle();

      // CameraCaptureScreen is open
      expect(find.text('Kamera Bukti Parkir'), findsOneWidget);
      expect(find.byKey(const Key('shutter_camera_button')), findsOneWidget);
      expect(find.byKey(const Key('close_camera_button')), findsOneWidget);

      // Tap shutter button to take evidence photo
      await tester.tap(find.byKey(const Key('shutter_camera_button')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));
      await tester.pumpAndSettle();

      // Screen is dismissed and returns result
      expect(capturedResult, isNotNull);
      expect(capturedResult!.bytes.isNotEmpty, isTrue);
      expect(capturedResult!.fileName, contains('bukti_kamera_'));
    },
  );
}
